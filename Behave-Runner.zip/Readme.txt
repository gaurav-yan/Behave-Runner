How to use it:

Double-click setup.bat.

Wait for it to finish.

To run the app later, you can just run this command in your terminal (or create a run.bat with this line):

venv\Scripts\streamlit run app.py

How to use:
Windows: Just double-click run_app.bat.

Mac/Linux: Open terminal, go to the folder, and type ./run_app.sh.
Important: You must make it executable by running chmod +x run_app.sh in your terminal first.
